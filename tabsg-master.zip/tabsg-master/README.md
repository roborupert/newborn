**TheAutobot** - a Telegram bot-platform for selling goods.

Written in Ruby Sinatra, this bot platform is highly flexible and scalable.
Just hit [@TheAutobot](http://google.com) on Telegram and create your own bot. Start selling )
