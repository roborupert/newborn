#!/bin/bash
bot_name="$1"
ruby setwebhook.rb "$bot_name"

