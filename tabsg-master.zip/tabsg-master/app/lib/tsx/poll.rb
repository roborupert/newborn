module TSX
  module Poll

      # def method_missing(method)
      #     handle("answer_#{method}")
      #     ask(step['question'], step['answers'])
      # end


  end
end