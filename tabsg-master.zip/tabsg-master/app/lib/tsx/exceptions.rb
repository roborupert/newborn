module TSX

  class TSXException < Exception
  end

end