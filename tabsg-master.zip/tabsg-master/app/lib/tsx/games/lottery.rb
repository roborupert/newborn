module TSX
    module Lottery

      def self.progress(game)
        "#{game.conf('counter')} просмотров."
      end

      def winner
      end

      def approved?
      end

    end
end