module TSX

    module Announcement

      def self.progress(game)
        "#{game.conf('counter')} просмотров."
      end

      def winner
        ""
      end

      def approved?

      end

    end

end