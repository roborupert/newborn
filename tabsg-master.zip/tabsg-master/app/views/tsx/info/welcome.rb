*Darkside Robot*
`#{Version.current}`

Сделок #{@tsx_bot.escrows(Escrow::ACTIVE).count}
****
[['Привязать', 'Сделки'], ['Главная']]