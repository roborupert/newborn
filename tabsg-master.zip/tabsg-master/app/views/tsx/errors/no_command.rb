#{icon(@tsx_bot.icon_warning)} Такой команды не знаю.
****
[[btn_main]]
