#{icon(@tsx_bot.icon_warning)} Непредвиденная ошибка.
****
[[btn_main]]
