#{icon(@tsx_bot.icon_warning, 'Такого вида не сущестует на диске.')} #{@view_file}
****
