#{client_details(hb_client)}
****
[[]]