#{icon('secret')} Ваши клады
****
buts = send(@what, @list)
buts
