#{icon('memo')} *Внутренние счета.*

#{system_clients(@tsx_bot)}
****
[[]]