#{_sbuy.long_title}
Чтобы оплатить клад через BTCU.biz, просто введите код активации с чека.
****
[
    [
        button('BTC-E USD', 'btce'),
    ]
]
