#{@klad.photo}
****
[
  [
    icon('+1', 'Хорошо'),
    icon('-1', 'Плохо')
  ],
  [
    btn_later
  ]
]