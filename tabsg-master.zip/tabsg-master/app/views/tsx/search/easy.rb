Для того, чтобы оплатить клад через EasyPay терминал, сделайте перевод на кошелек: #{conf('easypay_keeper')}
****
[
    [
        button(icon('no_entry', 'Отменить заказ'), 'cancel_trade')
    ]
]
