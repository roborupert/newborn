#{icon(@tsx_bot.icon_referals)} *Реферальная программа*
Друзья! Хорошие новости! С сегодняшнего дня мы делаем выплаты в размере *#{@tsx_bot.get_var('ref_rate')}% оборота* с привлеченных Вами людей. Вот ваша ссылка:
[#{hb_client.make_referal_link(@tsx_bot)}](#{hb_client.make_referal_link(@tsx_bot)})
Подробней читайте у себя в Кабинете.
****
[[]]
