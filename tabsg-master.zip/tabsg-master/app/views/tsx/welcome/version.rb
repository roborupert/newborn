#{icon(conf('bot_icon'))} *#{conf('bot_name')}*  `#{Version.current}`
****
