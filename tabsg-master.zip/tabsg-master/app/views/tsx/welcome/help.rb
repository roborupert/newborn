#{icon(@tsx_bot.icon_help)} *Служба поддержки.*

По любым вопросам обращайтесь в #{"поддержку" if !@tsx_bot.support.nil?} #{"[@#{@tsx_bot.support}](t.me/#{@tsx_bot.support})" if !@tsx_bot.support.nil?}. Также прочитайте каждый раздел, чтобы понять как мы работаем.
****
help_buttons