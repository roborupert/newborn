#{icon(@tsx_bot.icon_new_item)} Сделайте фото клада и загрузите сюда изображение.
****
[
  [
    icon(@tsx_bot.icon_cancel, 'Отменить')
  ]
]