#{icon(@tsx_bot.icon_new_item)} Введите подробное описание клада и нажмите Enter.
****
[[]]