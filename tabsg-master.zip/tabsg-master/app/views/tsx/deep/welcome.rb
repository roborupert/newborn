*Страховой бот Theautobot*
`#{Version.current}`

Клиент #{icon('id')} *#{hb_client.id}*
Баланс *#{@tsx_bot.amo(hb_client.available_cash)}*
Активных сделок *3*
Депонировано *1200USD*
****
[[icon('shield', 'Создать сделку')]]