class Mistake < Sequel::Model(:mistake)

end