class Exmocode < Sequel::Model(:exmo)
end