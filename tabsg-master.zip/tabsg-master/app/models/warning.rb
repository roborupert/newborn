class Warn < Sequel::Model(:warning)
  ACTIVE = 1
  INACTIVE = 0
end