class Rec < Sequel::Model(:rec)

end