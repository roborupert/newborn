class Mess < Sequel::Model(:mess)
  include TSX::Helpers
end