class Ref < Sequel::Model(:ref)

end