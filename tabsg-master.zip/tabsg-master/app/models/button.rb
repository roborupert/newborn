class Button < Sequel::Model(:button)
end