class Stat < Sequel::Model(:stat)
end