class Abuse < Sequel::Model(:abuse)
end