class Request < Sequel::Model(:request)
end