class Try < Sequel::Model(:try)
end