class Bet < Sequel::Model(:bet)
end