class Vars < Sequel::Model(:vars)
end