module TSX
  module Extension

    module Operator


    end

  end
end