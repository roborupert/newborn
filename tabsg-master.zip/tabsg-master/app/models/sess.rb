class Sess < Sequel::Model(:sess)

end