module TSX
  class Invoice < Sequel::Model(:invoice)
  end
end