class Team < Sequel::Model(:team)
end